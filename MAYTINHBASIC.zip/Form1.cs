﻿using System.Data;
namespace maytinhdongian2022
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            lbl_old.Text += btn.Text;
            action();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lbl_old.Text = "";
            lbl_result.Text = "";
        }

        private double tinh(string contents)
        {
            DataTable tb = new DataTable();
            return Convert.ToDouble(tb.Compute(contents,String.Empty));
        }

        private void action()
        {
            try
            {
                var result = tinh(lbl_old.Text);
                lbl_result.Text = Convert.ToString(result);
            }
            catch
            {
                lbl_result.Text = "Không tính được";
            }
        }
        private void btn_delete(object sender, EventArgs e)
        {
            char[] str_c = lbl_old.Text.ToArray();
            str_c[str_c.Length - 1] = ' ';
            lbl_old.Text = "";
            foreach (char c in str_c)
            {
                lbl_old.Text += Convert.ToString(c);
            }
            lbl_old.Text = lbl_old.Text.Replace(" ", "");
            action();
        }
    }
}